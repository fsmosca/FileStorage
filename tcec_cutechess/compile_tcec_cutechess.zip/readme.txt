source: https://github.com/TCEC-Chess/tceccutechess
